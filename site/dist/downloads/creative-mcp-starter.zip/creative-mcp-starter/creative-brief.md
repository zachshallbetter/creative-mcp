# Creative brief

## Working title
A place for ideas

## Goal
Create one compact graphic that can be used as a visual element in a simple 3D scene. Choose a theme and make the relationship between the graphic and the scene intentional.

## Constraints
- Keep the artwork readable at small size.
- Use a small palette inspired by the tools you use.
- Preserve an editable source file before exporting.
- Decide the export format based on the target operation and your application versions.

## Handoff notes
Record the source application, export format, dimensions, color assumptions, Blender import method, and any cleanup you performed. Moving the file between applications is a manual step in this exercise.

## Review
Can another person identify the focal point? Does the imported asset behave as expected in the scene? Which steps were automated by a tool, and which were performed manually?
