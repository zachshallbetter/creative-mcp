# Creative MCP starter: layout to 3D

A small exercise for exploring two independent local MCP implementations: Adobe MCP and Blender MCP.

## What this is

- A creative brief for making a simple graphic in Illustrator or InDesign.
- A transparent SVG reference board you can open or place in a creative application.
- A handoff checklist for carrying an exported asset into a Blender scene.

## What this is not

This pack does not install MCP servers, configure an MCP client, inspect your computer, move files, or connect Adobe MCP directly to Blender MCP. The servers are separate projects. You choose an export format supported by your workflow and manually transfer/import the file.

## Suggested exercise

1. In Illustrator or InDesign, create a simple title card for an imagined creative space. Use the supplied board as visual reference, not as a required template.
2. Export the artwork in a format suited to your Blender goal. Check the chosen format and import options in the application versions you use.
3. Save a working copy of the exported file somewhere you control.
4. Import it into Blender using Blender's own interface or a supported Blender MCP tool.
5. If connected, use Blender MCP to inspect the scene with `get_scene_info`; make only changes supported by the installed tool set.
6. Compare the result with your original brief and record the application, client, versions, manual steps and what you verified.

## Local setup

Use the setup instructions in each project's current documentation. Adobe MCP requires Node.js 18 or later and the relevant Adobe application. Blender MCP requires its CLI and Blender companion add-on. MCP clients launch these servers locally.

- Creative MCP: https://creativemcp.com/start.html
- Adobe MCP: https://github.com/zachshallbetter/adobe-mcp
- Blender MCP: https://github.com/zachshallbetter/blender-mcp-rs
